#ifndef SCANNER_H
#define SCANNER_H

#include "global.h"

void initialize_scanner();
TokenType get_token();

#endif // SCANNER_H